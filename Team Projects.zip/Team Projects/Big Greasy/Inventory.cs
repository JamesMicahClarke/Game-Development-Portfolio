using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/***********************************************
 * Filename:  		Inventory.cs
 * Date:      		04/11/2023
 * Mod. Date: 		05/01/2023
 * Mod. Initials:	JC
 * Author:    		James Clarke 
 ************************************************/

/// <summary>
/// Unused?
/// </summary>
public class Inventory : MonoBehaviour
{
    //ItemPickup pickup;
    //private void Start()
    //{
    //    //pickup = GetComponent()
    //}
    //void Update()
    //{
    //    if (pickup.HasObject)
    //    {

    //    }
    //    AddItem();
    //}

    //private void AddItem()
    //{
    //    if (true)
    //    {

    //    }
    //}
}
